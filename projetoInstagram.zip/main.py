"""
pip install..
flask
flask_login
flask_wtf
email_validator
flask_bcrypt
flask_sqlalchemy

"""
from instagram import app

if __name__ == '__main__':
    app.run(debug=True)


